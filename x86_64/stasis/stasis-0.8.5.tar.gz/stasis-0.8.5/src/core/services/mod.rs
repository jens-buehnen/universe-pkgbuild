pub mod app_inhibit;
pub mod browser_media;
pub mod dbus;
pub mod input;
pub mod media;
pub mod power_detection;
pub mod wayland;
