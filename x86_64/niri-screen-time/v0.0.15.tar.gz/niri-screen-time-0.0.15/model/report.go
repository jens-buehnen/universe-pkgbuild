// Package model
package model

type Report struct {
	Name   string `json:"name"`
	TimeMs int    `json:"time_ms"`
}
